# Express Token Server

This Express application provides an endpoint where a front-end application may request a JWT token for use with a Soul Machines websocket connection.

## Localhost Development & Testing

### 1. Generating a Self-Signed SSL Key and Cert

To enable local development utilizing HTTPS, you will need a self signed certificate.
The certificate should be stored in a subdirectory within the solution named 'certs'. You may use any subdirectory / certificate name, provided the .env file references a valid certificate.

The following instructions are provided as a reference only. If you experience difficulty, please consider an alternative mechanism to host HTTPS for local development or alternative methods to generate a self signed HTTPS certificate.

#### 1.a For Linux or Mac

You can use the script below (for linux/mac) users:

- `mkdir certs`
- `cd certs`
- `../scripts/generate-ssl.sh localhost`

#### 1.b. For Windows

Install `OpenSSL`, [follow these instructions](https://www.xolphin.com/support/OpenSSL/OpenSSL_-_Installation_under_Windows).

Run the following commands in your command line.

```
mkdir certs
cd certs
openssl req -new -nodes -subj /C=NZ/commonName=localhost -keyout localhost.key -out localhost.csr
openssl x509 -req -days 3650 -in localhost.csr -signkey localhost.key -out localhost.crt
cd ..








### 2. Environment variable configuration
Environment variables are required to be configured in the .env file
See .env for further information.

### 3. Running locally
- Run `npm install` to install all dependencies
- Run `npm run dev` to start the localhost server
- To connect to your server from your frontend app, you will need to allow your self-signed cert to be used in Chrome.
  Navigate to your token server in your browser `https://localhost:5000/ping` and choose to "proceed to unsafe site".
- To validate the token being served, navigate to `https://localhost:5000/auth/authorize`

## Remote Deployment
- Run `npm run build` to create a build for remote deployment
```
